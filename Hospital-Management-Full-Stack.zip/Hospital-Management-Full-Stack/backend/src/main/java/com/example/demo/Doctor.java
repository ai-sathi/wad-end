package com.example.demo;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="doctors")
public class Doctor {
 @Id private String id;
 private String doctorId;
 private String doctorName;
 private String specialization;
 private String room;
 public Doctor() {}
 public String getId(){return id;} public void setId(String v){id=v;}
 public String getDoctorId(){return doctorId;} public void setDoctorId(String v){doctorId=v;}
 public String getDoctorName(){return doctorName;} public void setDoctorName(String v){doctorName=v;}
 public String getSpecialization(){return specialization;} public void setSpecialization(String v){specialization=v;}
 public String getRoom(){return room;} public void setRoom(String v){room=v;}
}
