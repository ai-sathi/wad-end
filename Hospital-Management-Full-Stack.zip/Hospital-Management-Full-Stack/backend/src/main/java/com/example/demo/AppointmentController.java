package com.example.demo;
import java.util.List;
import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;
@RestController
@RequestMapping("/appointments")
@CrossOrigin(origins="http://localhost:5173")
public class AppointmentController {
 private final AppointmentRepository repo;
 private final MongoTemplate mongoTemplate;
 public AppointmentController(AppointmentRepository repo,MongoTemplate mongoTemplate){this.repo=repo;this.mongoTemplate=mongoTemplate;}
 @GetMapping public List<Appointment> all(){return repo.findAll();}
 @GetMapping("/{id}") public Appointment one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Appointment not found"));}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Appointment create(@RequestBody Appointment a){
  if(a.getAppointmentId()==null||a.getAppointmentId().isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Appointment ID required");
  if(repo.existsByAppointmentId(a.getAppointmentId())) throw new ResponseStatusException(HttpStatus.CONFLICT,"Appointment ID already exists");
  a.setId(null); return repo.save(a);
 }
 @PutMapping("/{id}") public Appointment update(@PathVariable String id,@RequestBody Appointment input){
  Appointment a=repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Appointment not found"));
  a.setAppointmentId(input.getAppointmentId()); a.setDoctorId(input.getDoctorId()); a.setPatientName(input.getPatientName()); a.setPatientAge(input.getPatientAge()); a.setDate(input.getDate()); a.setStatus(input.getStatus()); return repo.save(a);
 }
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){
  if(!repo.existsById(id)) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Appointment not found"); repo.deleteById(id);
 }
 @GetMapping("/status/{status}") public List<Appointment> byStatus(@PathVariable String status){return repo.findByStatusIgnoreCase(status);}
 @GetMapping("/with-doctors") public List<Document> withDoctors(){
  LookupOperation lookup=lookup("doctors","doctorId","doctorId","doctorDetails");
  Aggregation aggregation=newAggregation(lookup,unwind("doctorDetails"),
   project().and("appointmentId").as("appointmentId").and("patientName").as("patientName")
    .and("patientAge").as("patientAge").and("date").as("date").and("status").as("status")
    .and("doctorDetails.doctorName").as("doctorName").and("doctorDetails.specialization").as("specialization")
    .and("doctorDetails.room").as("room"));
  AggregationResults<Document> results=mongoTemplate.aggregate(aggregation,"appointments",Document.class);
  return results.getMappedResults();
 }
 @GetMapping("/completed-count-by-doctor") public List<Document> completedCount(){
  Aggregation aggregation=newAggregation(match(Criteria.where("status").is("Completed")),
   group("doctorId").count().as("completedAppointments"),
   project("completedAppointments").and("_id").as("doctorId"));
  return mongoTemplate.aggregate(aggregation,"appointments",Document.class).getMappedResults();
 }
}
