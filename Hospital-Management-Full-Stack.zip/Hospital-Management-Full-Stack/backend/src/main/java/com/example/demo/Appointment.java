package com.example.demo;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="appointments")
public class Appointment {
 @Id private String id;
 private String appointmentId;
 private String doctorId;
 private String patientName;
 private Integer patientAge;
 private String date;
 private String status;
 public Appointment() {}
 public String getId(){return id;} public void setId(String v){id=v;}
 public String getAppointmentId(){return appointmentId;} public void setAppointmentId(String v){appointmentId=v;}
 public String getDoctorId(){return doctorId;} public void setDoctorId(String v){doctorId=v;}
 public String getPatientName(){return patientName;} public void setPatientName(String v){patientName=v;}
 public Integer getPatientAge(){return patientAge;} public void setPatientAge(Integer v){patientAge=v;}
 public String getDate(){return date;} public void setDate(String v){date=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;}
}
