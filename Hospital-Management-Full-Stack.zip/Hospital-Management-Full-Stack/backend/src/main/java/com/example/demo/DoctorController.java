package com.example.demo;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
@RestController
@RequestMapping("/doctors")
@CrossOrigin(origins="http://localhost:5173")
public class DoctorController {
 private final DoctorRepository repo;
 public DoctorController(DoctorRepository repo){this.repo=repo;}
 @GetMapping public List<Doctor> all(){return repo.findAll();}
 @GetMapping("/{id}") public Doctor one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Doctor not found"));}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Doctor create(@RequestBody Doctor d){
  if(d.getDoctorId()==null||d.getDoctorId().isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Doctor ID required");
  if(repo.existsByDoctorId(d.getDoctorId())) throw new ResponseStatusException(HttpStatus.CONFLICT,"Doctor ID already exists");
  d.setId(null); return repo.save(d);
 }
 @PutMapping("/{id}") public Doctor update(@PathVariable String id,@RequestBody Doctor input){
  Doctor d=repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Doctor not found"));
  d.setDoctorId(input.getDoctorId()); d.setDoctorName(input.getDoctorName()); d.setSpecialization(input.getSpecialization()); d.setRoom(input.getRoom()); return repo.save(d);
 }
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){
  if(!repo.existsById(id)) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Doctor not found"); repo.deleteById(id);
 }
}
