# Hospital Management Full-Stack Lab Project

**Stack:** Vue 3 (Options API + fetch), Spring Boot, MongoDB. Two collections: `doctors` and `appointments`. Includes CRUD for both, joined aggregation, and responsive grid/card UI.

## Run
1. Start MongoDB locally.
2. Open `backend` in IntelliJ as a Maven project; run `com.example.demo.HospitalApplication`. Requires JDK 17+ (Java 21 works).
3. In a terminal: `cd frontend`, `npm install`, `npm run dev`.
4. Open the Vite URL (normally http://localhost:5173).

Database: `hospitaldb`; backend: `http://localhost:8080`.

## Aggregation
`GET /appointments/with-doctors` joins `appointments.doctorId` to `doctors.doctorId` using `$lookup`, `$unwind`, and `$project`.

## APIs
Doctors: `GET/POST /doctors`, `GET/PUT/DELETE /doctors/{mongoDocumentId}`
Appointments: `GET/POST /appointments`, `GET/PUT/DELETE /appointments/{mongoDocumentId}`, `GET /appointments/with-doctors`, `GET /appointments/status/{status}`

Create a doctor first. When creating an appointment, select a doctor so the business `doctorId` matches for aggregation.
