<template>
<div class="shell">
<header><div class="logo">✚</div><div><b>CarePoint</b><small>HOSPITAL MANAGEMENT</small></div><span class="header-note">● Management workspace</span></header>
<main>
<section class="hero"><div><p class="eyebrow">HOSPITAL OPERATIONS</p><h1>Better organized care.<br><em>One clear workspace.</em></h1><p>Manage doctors and appointments with a simple full-stack application.</p></div><div class="hero-symbol">✚</div></section>
<div v-if="notice" class="notice" :class="{error:isError}">{{notice}} <button @click="notice=''">×</button></div>
<section class="stats">
<div class="stat"><span class="bubble">✚</span><div><small>Total doctors</small><strong>{{doctors.length}}</strong></div></div>
<div class="stat"><span class="bubble purple">▣</span><div><small>Appointments</small><strong>{{appointments.length}}</strong></div></div>
<div class="stat"><span class="bubble green">✓</span><div><small>Completed</small><strong>{{completedCount}}</strong></div></div>
</section>
<section class="heading"><div><p class="eyebrow">WORKSPACE</p><h2>Manage records</h2></div><div class="actions"><button class="btn light" @click="loadAll">↻ Refresh</button><button class="btn" @click="openDoctor()">＋ Add doctor</button><button class="btn" @click="openAppointment()">＋ Add appointment</button></div></section>
<nav class="tabs"><button :class="{active:tab==='appointments'}" @click="tab='appointments'">Appointments <span>{{appointments.length}}</span></button><button :class="{active:tab==='doctors'}" @click="tab='doctors'">Doctors <span>{{doctors.length}}</span></button><button :class="{active:tab==='joined'}" @click="tab='joined';loadJoined()">Joined view <i>Aggregation</i></button></nav>
<section v-if="tab==='appointments'" class="panel">
<div class="panel-head"><div><h3>Appointments</h3><p>Search and manage patient appointments.</p></div><input v-model="searchA" placeholder="Search patient, ID or status…"></div>
<div v-if="filteredAppointments.length" class="grid">
<article v-for="a in filteredAppointments" :key="a.id" class="card"><div class="card-top"><span class="avatar purple">{{initials(a.patientName)}}</span><span class="pill" :class="a.status.toLowerCase()">{{a.status}}</span></div><h3>{{a.patientName}}</h3><p class="sub">Appointment {{a.appointmentId}}</p><div class="details"><div><span>Doctor ID</span><b>{{a.doctorId}}</b></div><div><span>Date</span><b>{{a.date||'—'}}</b></div><div><span>Patient age</span><b>{{a.patientAge}}</b></div></div><div class="card-actions"><button class="btn light small" @click="editAppointment(a)">Edit</button><button class="btn danger small" @click="deleteAppointment(a)">Delete</button></div></article>
</div><div v-else class="empty"><span>▤</span><h3>No appointments found</h3><p>Add an appointment or change your search.</p><button class="btn" @click="openAppointment()">Add appointment</button></div>
</section>
<section v-if="tab==='doctors'" class="panel">
<div class="panel-head"><div><h3>Medical team</h3><p>Manage doctor profiles and room assignments.</p></div><input v-model="searchD" placeholder="Search doctor, ID or specialty…"></div>
<div v-if="filteredDoctors.length" class="grid">
<article v-for="d in filteredDoctors" :key="d.id" class="card"><div class="card-top"><span class="avatar">{{initials(d.doctorName)}}</span><span class="id">{{d.doctorId}}</span></div><h3>{{d.doctorName}}</h3><p class="sub">{{d.specialization}}</p><div class="details"><div><span>Room</span><b>{{d.room||'Not assigned'}}</b></div><div><span>Appointments</span><b>{{appointments.filter(a=>a.doctorId===d.doctorId).length}}</b></div></div><div class="card-actions"><button class="btn light small" @click="editDoctor(d)">Edit</button><button class="btn danger small" @click="deleteDoctor(d)">Delete</button></div></article>
</div><div v-else class="empty"><span>✚</span><h3>No doctors found</h3><p>Add a doctor before creating appointments.</p><button class="btn" @click="openDoctor()">Add doctor</button></div>
</section>
<section v-if="tab==='joined'" class="panel"><div class="panel-head"><div><h3>Appointments with doctor details</h3><p>Aggregation joins appointments and doctors.</p></div><button class="btn light" @click="loadJoined">↻ Run aggregation</button></div>
<div v-if="joined.length" class="table-wrap"><table><thead><tr><th>Appointment</th><th>Patient</th><th>Doctor</th><th>Specialization</th><th>Date</th><th>Status</th></tr></thead><tbody><tr v-for="(a,i) in joined" :key="a.appointmentId||i"><td>{{a.appointmentId}}</td><td>{{a.patientName}}</td><td>{{a.doctorName}}</td><td>{{a.specialization}}</td><td>{{a.date||'—'}}</td><td><span class="pill" :class="a.status.toLowerCase()">{{a.status}}</span></td></tr></tbody></table></div>
<div v-else class="empty"><span>⌘</span><h3>No joined records</h3><p>Add a doctor and appointment with matching Doctor IDs, then run aggregation.</p><button class="btn" @click="loadJoined">Run aggregation</button></div>
<div class="pipeline"><b>Pipeline</b><code>$lookup → $unwind → $project</code><span>appointments.doctorId = doctors.doctorId</span></div></section>
<footer>CarePoint · Lab practice <span>Vue 3 · Spring Boot · MongoDB</span></footer>
</main>
<div v-if="modal" class="backdrop" @click.self="modal=false"><section class="dialog"><div class="dialog-head"><div><p class="eyebrow">{{editing?'UPDATE RECORD':'NEW RECORD'}}</p><h2>{{formType==='doctor'?(editing?'Edit doctor':'Add doctor'):(editing?'Edit appointment':'Add appointment')}}</h2></div><button class="close" @click="modal=false">×</button></div>
<form v-if="formType==='doctor'" @submit.prevent="saveDoctor"><div class="form-grid"><label>Doctor ID<input v-model.trim="doctorForm.doctorId" required placeholder="D101"></label><label>Doctor name<input v-model.trim="doctorForm.doctorName" required placeholder="Dr. Ravi"></label><label>Specialization<select v-model="doctorForm.specialization" required><option disabled value="">Choose specialty</option><option>Cardiology</option><option>Neurology</option><option>Orthopedics</option><option>Pediatrics</option><option>Dermatology</option><option>General Medicine</option><option>ENT</option><option>Oncology</option></select></label><label>Room number<input v-model.trim="doctorForm.room" placeholder="101"></label></div><p class="help">Doctor ID is the business key used by aggregation.</p><div class="dialog-actions"><button type="button" class="btn light" @click="modal=false">Cancel</button><button class="btn" :disabled="saving">{{saving?'Saving…':'Save doctor'}}</button></div></form>
<form v-else @submit.prevent="saveAppointment"><div class="form-grid"><label>Appointment ID<input v-model.trim="appointmentForm.appointmentId" required placeholder="A101"></label><label>Patient name<input v-model.trim="appointmentForm.patientName" required placeholder="Patient name"></label><label>Doctor<select v-model="appointmentForm.doctorId" required><option disabled value="">Choose a doctor</option><option v-for="d in doctors" :key="d.doctorId" :value="d.doctorId">{{d.doctorName}} ({{d.doctorId}})</option></select></label><label>Patient age<input v-model.number="appointmentForm.patientAge" type="number" min="0" max="120" required></label><label>Appointment date<input v-model="appointmentForm.date" type="date" required></label><label>Status<select v-model="appointmentForm.status"><option>Scheduled</option><option>Completed</option><option>Cancelled</option></select></label></div><p class="help">Choose an existing doctor so the join key matches.</p><div class="dialog-actions"><button type="button" class="btn light" @click="modal=false">Cancel</button><button class="btn" :disabled="saving||!doctors.length">{{saving?'Saving…':'Save appointment'}}</button></div></form>
</section></div>
</div>
</template>
<script>
const API='http://localhost:8080'
export default {
 data(){return {doctors:[],appointments:[],joined:[],tab:'appointments',searchA:'',searchD:'',modal:false,formType:'doctor',editing:false,editId:null,saving:false,notice:'',isError:false,doctorForm:this.emptyDoctor(),appointmentForm:this.emptyAppointment()}},
 computed:{
  completedCount(){return this.appointments.filter(a=>(a.status||'').toLowerCase()==='completed').length},
  filteredAppointments(){let q=this.searchA.toLowerCase();return this.appointments.filter(a=>[a.patientName,a.appointmentId,a.doctorId,a.status,a.date].some(v=>String(v||'').toLowerCase().includes(q)))},
  filteredDoctors(){let q=this.searchD.toLowerCase();return this.doctors.filter(d=>[d.doctorName,d.doctorId,d.specialization,d.room].some(v=>String(v||'').toLowerCase().includes(q)))}
 },
 mounted(){this.loadAll()},
 methods:{
  emptyDoctor(){return {doctorId:'',doctorName:'',specialization:'',room:''}},
  emptyAppointment(){return {appointmentId:'',doctorId:'',patientName:'',patientAge:0,date:'',status:'Scheduled'}},
  async request(url,options={}){let r=await fetch(url,{...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});if(!r.ok){let msg=`Request failed (${r.status})`;try{let b=await r.json();msg=b.message||b.detail||msg}catch(e){}throw Error(msg)}if(r.status===204)return null;return r.json()},
  async loadAll(){try{let [d,a]=await Promise.all([this.request(API+'/doctors'),this.request(API+'/appointments')]);this.doctors=d;this.appointments=a;this.notice='Records refreshed.';this.isError=false;if(this.tab==='joined')await this.loadJoined()}catch(e){this.fail(e,'Could not load records. Start Spring Boot and MongoDB first.')}},
  async loadJoined(){try{this.joined=await this.request(API+'/appointments/with-doctors')}catch(e){this.fail(e,'Aggregation failed. Check backend and matching Doctor IDs.')}},
  fail(e,fallback){this.notice=e.message||fallback;this.isError=true},
  initials(v){return (v||'?').trim().split(/\\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase()},
  openDoctor(){this.formType='doctor';this.editing=false;this.editId=null;this.doctorForm=this.emptyDoctor();this.modal=true},
  openAppointment(){if(!this.doctors.length){this.tab='doctors';this.fail(Error('Add a doctor first, then create an appointment.'));return}this.formType='appointment';this.editing=false;this.editId=null;this.appointmentForm=this.emptyAppointment();this.modal=true},
  editDoctor(d){this.formType='doctor';this.editing=true;this.editId=d.id;this.doctorForm={doctorId:d.doctorId,doctorName:d.doctorName,specialization:d.specialization,room:d.room||''};this.modal=true},
  editAppointment(a){this.formType='appointment';this.editing=true;this.editId=a.id;this.appointmentForm={appointmentId:a.appointmentId,doctorId:a.doctorId,patientName:a.patientName,patientAge:a.patientAge,date:a.date||'',status:a.status||'Scheduled'};this.modal=true},
  async saveDoctor(){await this.saveRecord('doctor',this.doctorForm)},
  async saveAppointment(){await this.saveRecord('appointment',this.appointmentForm)},
  async saveRecord(type,data){this.saving=true;try{let path=type==='doctor'?'/doctors':'/appointments';await this.request(API+path+(this.editing?'/'+this.editId:''),{method:this.editing?'PUT':'POST',body:JSON.stringify(data)});let verb=this.editing?'updated':'created';this.modal=false;await this.loadAll();this.notice=`${type==='doctor'?'Doctor':'Appointment'} ${verb}.`;this.isError=false;if(this.tab==='joined')await this.loadJoined()}catch(e){this.fail(e,'Could not save record.')}finally{this.saving=false}},
  async deleteDoctor(d){if(!confirm(`Delete ${d.doctorName}? Existing appointments will remain.`))return;try{await this.request(API+'/doctors/'+d.id,{method:'DELETE'});await this.loadAll();this.notice='Doctor deleted.';this.isError=false}catch(e){this.fail(e,'Could not delete doctor.')}},
  async deleteAppointment(a){if(!confirm(`Delete appointment ${a.appointmentId}?`))return;try{await this.request(API+'/appointments/'+a.id,{method:'DELETE'});await this.loadAll();this.notice='Appointment deleted.';this.isError=false}catch(e){this.fail(e,'Could not delete appointment.')}}
 }
}
</script>
