package com.example.collegeplacement.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="students")
public class Student {
@Id private String id;
private String studentId;
private String name;
private String department;
private double cgpa;
private String email;
public Student(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getStudentId(){return studentId;} public void setStudentId(String studentId){this.studentId=studentId;}
public String getName(){return name;} public void setName(String name){this.name=name;}
public String getDepartment(){return department;} public void setDepartment(String department){this.department=department;}
public double getCgpa(){return cgpa;} public void setCgpa(double cgpa){this.cgpa=cgpa;}
public String getEmail(){return email;} public void setEmail(String email){this.email=email;}
}
