package com.example.collegeplacement.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("PLACED")),Document.class,"placements");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("students","studentId","studentId","relatedDetails"));return mongo.aggregate(a,"placements",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "students").append("localField", "studentId").append("foreignField", "studentId").append("as", "student")),
            stage("$unwind", "$student"),
            stage("$match", new Document().append("status", "SELECTED")),
            stage("$group", new Document().append("_id", new Document().append("studentId", "$studentId").append("studentName", new Document().append("$first", "$student.name")).append("department", new Document().append("$first", "$student.department")).append("cgpa", new Document().append("$first", "$student.cgpa"))).append("offers", new Document().append("$sum", 1)).append("highestPackageLpa", new Document().append("$max", "$packageLpa")).append("averagePackageLpa", new Document().append("$avg", "$packageLpa"))),
            stage("$match", new Document().append("highestPackageLpa", new Document().append("$gte", 6))),
            stage("$sort", new Document().append("highestPackageLpa", -1)),
            stage("$project", new Document().append("_id", 0).append("studentId", "$_id.studentId").append("studentName", "$_id.studentName").append("department", "$_id.department").append("cgpa", "$_id.cgpa").append("offers", 1).append("highestPackageLpa", 1).append("averagePackageLpa", 1))
        );
        return mongo.aggregate(aggregation, "placements", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
