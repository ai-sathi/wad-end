package com.example.gympayments.controller;
import com.example.gympayments.model.Payment; import com.example.gympayments.repository.PaymentRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/payments") @CrossOrigin(origins="http://localhost:5173")
public class PaymentController {
private final PaymentRepository repo; public PaymentController(PaymentRepository repo){this.repo=repo;}
@GetMapping public List<Payment> all(){return repo.findAll();}
@GetMapping("/{id}") public Payment one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Payment create(@RequestBody Payment x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Payment update(@PathVariable String id,@RequestBody Payment x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
