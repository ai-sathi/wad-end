package com.example.gympayments.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="members")
public class Member {
@Id private String id;
private String memberId;
private String name;
private String phone;
private String planType;
private boolean active;
public Member(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getMemberId(){return memberId;} public void setMemberId(String memberId){this.memberId=memberId;}
public String getName(){return name;} public void setName(String name){this.name=name;}
public String getPhone(){return phone;} public void setPhone(String phone){this.phone=phone;}
public String getPlanType(){return planType;} public void setPlanType(String planType){this.planType=planType;}
public boolean getActive(){return active;} public void setActive(boolean active){this.active=active;}
}
