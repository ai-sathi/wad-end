package com.example.gympayments.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="payments")
public class Payment {
@Id private String id;
private String paymentId;
private String memberId;
private double amount;
private String paymentDate;
private String status;
public Payment(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getPaymentId(){return paymentId;} public void setPaymentId(String paymentId){this.paymentId=paymentId;}
public String getMemberId(){return memberId;} public void setMemberId(String memberId){this.memberId=memberId;}
public double getAmount(){return amount;} public void setAmount(double amount){this.amount=amount;}
public String getPaymentDate(){return paymentDate;} public void setPaymentDate(String paymentDate){this.paymentDate=paymentDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
