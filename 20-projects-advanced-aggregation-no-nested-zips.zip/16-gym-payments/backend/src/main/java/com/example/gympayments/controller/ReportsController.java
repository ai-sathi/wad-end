package com.example.gympayments.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("DUE")),Document.class,"payments");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("members","memberId","memberId","relatedDetails"));return mongo.aggregate(a,"payments",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "members").append("localField", "memberId").append("foreignField", "memberId").append("as", "member")),
            stage("$unwind", "$member"),
            stage("$match", new Document().append("status", "PAID")),
            stage("$group", new Document().append("_id", new Document().append("memberId", "$memberId").append("memberName", new Document().append("$first", "$member.name")).append("planType", new Document().append("$first", "$member.planType"))).append("successfulPayments", new Document().append("$sum", 1)).append("totalPaid", new Document().append("$sum", "$amount")).append("averagePayment", new Document().append("$avg", "$amount"))),
            stage("$match", new Document().append("totalPaid", new Document().append("$gt", 1000))),
            stage("$sort", new Document().append("totalPaid", -1)),
            stage("$project", new Document().append("_id", 0).append("memberId", "$_id.memberId").append("memberName", "$_id.memberName").append("planType", "$_id.planType").append("successfulPayments", 1).append("totalPaid", 1).append("averagePayment", 1))
        );
        return mongo.aggregate(aggregation, "payments", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
