package com.example.flightbooking.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("availableSeats").is(0)),Document.class,"flights");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("flights","flightId","flightId","relatedDetails"));return mongo.aggregate(a,"flightBookings",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "flights").append("localField", "flightId").append("foreignField", "flightId").append("as", "flight")),
            stage("$unwind", "$flight"),
            stage("$match", new Document().append("status", "CONFIRMED")),
            stage("$group", new Document().append("_id", new Document().append("flightId", "$flightId").append("airline", new Document().append("$first", "$flight.airline")).append("source", new Document().append("$first", "$flight.source")).append("destination", new Document().append("$first", "$flight.destination"))).append("confirmedBookings", new Document().append("$sum", 1)).append("seatsReserved", new Document().append("$sum", "$seatsBooked"))),
            stage("$match", new Document().append("seatsReserved", new Document().append("$gte", 3))),
            stage("$sort", new Document().append("seatsReserved", -1)),
            stage("$project", new Document().append("_id", 0).append("flightId", "$_id.flightId").append("airline", "$_id.airline").append("source", "$_id.source").append("destination", "$_id.destination").append("confirmedBookings", 1).append("seatsReserved", 1))
        );
        return mongo.aggregate(aggregation, "flightBookings", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
