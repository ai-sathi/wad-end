package com.example.flightbooking.repository;
import com.example.flightbooking.model.Flight;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface FlightRepository extends MongoRepository<Flight,String>{}
