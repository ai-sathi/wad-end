package com.example.flightbooking.controller;
import com.example.flightbooking.model.FlightBooking; import com.example.flightbooking.repository.FlightBookingRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/flightBookings") @CrossOrigin(origins="http://localhost:5173")
public class FlightBookingController {
private final FlightBookingRepository repo; public FlightBookingController(FlightBookingRepository repo){this.repo=repo;}
@GetMapping public List<FlightBooking> all(){return repo.findAll();}
@GetMapping("/{id}") public FlightBooking one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public FlightBooking create(@RequestBody FlightBooking x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public FlightBooking update(@PathVariable String id,@RequestBody FlightBooking x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
