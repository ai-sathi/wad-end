package com.example.flightbooking.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="flightBookings")
public class FlightBooking {
@Id private String id;
private String bookingId;
private String passengerName;
private String flightId;
private int seatsBooked;
private String travelDate;
private String status;
public FlightBooking(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getBookingId(){return bookingId;} public void setBookingId(String bookingId){this.bookingId=bookingId;}
public String getPassengerName(){return passengerName;} public void setPassengerName(String passengerName){this.passengerName=passengerName;}
public String getFlightId(){return flightId;} public void setFlightId(String flightId){this.flightId=flightId;}
public int getSeatsBooked(){return seatsBooked;} public void setSeatsBooked(int seatsBooked){this.seatsBooked=seatsBooked;}
public String getTravelDate(){return travelDate;} public void setTravelDate(String travelDate){this.travelDate=travelDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
