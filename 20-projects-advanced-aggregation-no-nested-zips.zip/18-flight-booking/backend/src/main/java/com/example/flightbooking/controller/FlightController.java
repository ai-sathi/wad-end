package com.example.flightbooking.controller;
import com.example.flightbooking.model.Flight; import com.example.flightbooking.repository.FlightRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/flights") @CrossOrigin(origins="http://localhost:5173")
public class FlightController {
private final FlightRepository repo; public FlightController(FlightRepository repo){this.repo=repo;}
@GetMapping public List<Flight> all(){return repo.findAll();}
@GetMapping("/{id}") public Flight one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Flight create(@RequestBody Flight x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Flight update(@PathVariable String id,@RequestBody Flight x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
