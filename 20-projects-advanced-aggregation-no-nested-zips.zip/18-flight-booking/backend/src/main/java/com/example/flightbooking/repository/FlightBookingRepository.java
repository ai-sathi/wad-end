package com.example.flightbooking.repository;
import com.example.flightbooking.model.FlightBooking;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface FlightBookingRepository extends MongoRepository<FlightBooking,String>{}
