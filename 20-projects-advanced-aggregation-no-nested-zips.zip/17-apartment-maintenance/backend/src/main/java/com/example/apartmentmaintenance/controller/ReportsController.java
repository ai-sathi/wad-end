package com.example.apartmentmaintenance.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("OPEN")),Document.class,"maintenanceRequests");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("apartments","apartmentId","apartmentId","relatedDetails"));return mongo.aggregate(a,"maintenanceRequests",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "apartments").append("localField", "apartmentId").append("foreignField", "apartmentId").append("as", "apartment")),
            stage("$unwind", "$apartment"),
            stage("$match", new Document().append("status", new Document().append("$in", java.util.Arrays.asList("OPEN", "PENDING")))),
            stage("$group", new Document().append("_id", new Document().append("apartmentId", "$apartmentId").append("unitNumber", new Document().append("$first", "$apartment.unitNumber")).append("residentName", new Document().append("$first", "$apartment.residentName")).append("building", new Document().append("$first", "$apartment.building"))).append("openRequests", new Document().append("$sum", 1))),
            stage("$match", new Document().append("openRequests", new Document().append("$gte", 2))),
            stage("$sort", new Document().append("openRequests", -1)),
            stage("$project", new Document().append("_id", 0).append("apartmentId", "$_id.apartmentId").append("unitNumber", "$_id.unitNumber").append("residentName", "$_id.residentName").append("building", "$_id.building").append("openRequests", 1))
        );
        return mongo.aggregate(aggregation, "maintenanceRequests", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
