package com.example.apartmentmaintenance.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="maintenanceRequests")
public class MaintenanceRequest {
@Id private String id;
private String requestId;
private String apartmentId;
private String issueType;
private String description;
private String requestDate;
private String status;
public MaintenanceRequest(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getRequestId(){return requestId;} public void setRequestId(String requestId){this.requestId=requestId;}
public String getApartmentId(){return apartmentId;} public void setApartmentId(String apartmentId){this.apartmentId=apartmentId;}
public String getIssueType(){return issueType;} public void setIssueType(String issueType){this.issueType=issueType;}
public String getDescription(){return description;} public void setDescription(String description){this.description=description;}
public String getRequestDate(){return requestDate;} public void setRequestDate(String requestDate){this.requestDate=requestDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
