package com.example.onlineshopping.repository;
import com.example.onlineshopping.model.Product;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ProductRepository extends MongoRepository<Product,String>{}
