package com.example.onlineshopping.controller;
import com.example.onlineshopping.model.Product; import com.example.onlineshopping.repository.ProductRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/products") @CrossOrigin(origins="http://localhost:5173")
public class ProductController {
private final ProductRepository repo; public ProductController(ProductRepository repo){this.repo=repo;}
@GetMapping public List<Product> all(){return repo.findAll();}
@GetMapping("/{id}") public Product one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Product create(@RequestBody Product x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Product update(@PathVariable String id,@RequestBody Product x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
