package com.example.onlineshopping.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("stock").lt(10)),Document.class,"products");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("products","productId","productId","relatedDetails"));return mongo.aggregate(a,"orders",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "products").append("localField", "productId").append("foreignField", "productId").append("as", "product")),
            stage("$unwind", "$product"),
            stage("$match", new Document().append("status", "DELIVERED")),
            stage("$group", new Document().append("_id", new Document().append("productId", "$productId").append("productName", new Document().append("$first", "$product.name")).append("category", new Document().append("$first", "$product.category"))).append("deliveredOrderCount", new Document().append("$sum", 1)).append("revenue", new Document().append("$sum", "$totalAmount")).append("unitsSold", new Document().append("$sum", "$quantity"))),
            stage("$match", new Document().append("revenue", new Document().append("$gt", 1000))),
            stage("$sort", new Document().append("revenue", -1)),
            stage("$project", new Document().append("_id", 0).append("productId", "$_id.productId").append("productName", "$_id.productName").append("category", "$_id.category").append("deliveredOrderCount", 1).append("revenue", 1).append("unitsSold", 1))
        );
        return mongo.aggregate(aggregation, "orders", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
