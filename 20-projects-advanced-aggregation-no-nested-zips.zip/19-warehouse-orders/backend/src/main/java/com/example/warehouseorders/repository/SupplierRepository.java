package com.example.warehouseorders.repository;
import com.example.warehouseorders.model.Supplier;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface SupplierRepository extends MongoRepository<Supplier,String>{}
