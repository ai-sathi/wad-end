package com.example.warehouseorders.controller;
import com.example.warehouseorders.model.PurchaseOrder; import com.example.warehouseorders.repository.PurchaseOrderRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/purchaseOrders") @CrossOrigin(origins="http://localhost:5173")
public class PurchaseOrderController {
private final PurchaseOrderRepository repo; public PurchaseOrderController(PurchaseOrderRepository repo){this.repo=repo;}
@GetMapping public List<PurchaseOrder> all(){return repo.findAll();}
@GetMapping("/{id}") public PurchaseOrder one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public PurchaseOrder create(@RequestBody PurchaseOrder x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public PurchaseOrder update(@PathVariable String id,@RequestBody PurchaseOrder x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
