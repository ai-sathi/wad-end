package com.example.warehouseorders.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("PENDING")),Document.class,"purchaseOrders");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("suppliers","supplierId","supplierId","relatedDetails"));return mongo.aggregate(a,"purchaseOrders",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "suppliers").append("localField", "supplierId").append("foreignField", "supplierId").append("as", "supplier")),
            stage("$unwind", "$supplier"),
            stage("$match", new Document().append("status", "APPROVED")),
            stage("$group", new Document().append("_id", new Document().append("supplierId", "$supplierId").append("supplierName", new Document().append("$first", "$supplier.name"))).append("approvedOrders", new Document().append("$sum", 1)).append("totalUnitsOrdered", new Document().append("$sum", "$quantity"))),
            stage("$match", new Document().append("totalUnitsOrdered", new Document().append("$gte", 20))),
            stage("$sort", new Document().append("totalUnitsOrdered", -1)),
            stage("$project", new Document().append("_id", 0).append("supplierId", "$_id.supplierId").append("supplierName", "$_id.supplierName").append("approvedOrders", 1).append("totalUnitsOrdered", 1))
        );
        return mongo.aggregate(aggregation, "purchaseOrders", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
