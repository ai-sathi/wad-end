package com.example.restaurantorders.controller;
import com.example.restaurantorders.model.MenuItem; import com.example.restaurantorders.repository.MenuItemRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/menuItems") @CrossOrigin(origins="http://localhost:5173")
public class MenuItemController {
private final MenuItemRepository repo; public MenuItemController(MenuItemRepository repo){this.repo=repo;}
@GetMapping public List<MenuItem> all(){return repo.findAll();}
@GetMapping("/{id}") public MenuItem one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public MenuItem create(@RequestBody MenuItem x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public MenuItem update(@PathVariable String id,@RequestBody MenuItem x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
