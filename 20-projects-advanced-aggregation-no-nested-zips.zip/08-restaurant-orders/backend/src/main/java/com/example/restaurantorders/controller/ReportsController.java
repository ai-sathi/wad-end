package com.example.restaurantorders.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("PENDING")),Document.class,"foodOrders");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("menuItems","itemId","itemId","relatedDetails"));return mongo.aggregate(a,"foodOrders",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "menuItems").append("localField", "itemId").append("foreignField", "itemId").append("as", "menuItem")),
            stage("$unwind", "$menuItem"),
            stage("$match", new Document().append("status", "COMPLETED")),
            stage("$group", new Document().append("_id", new Document().append("itemId", "$itemId").append("itemName", new Document().append("$first", "$menuItem.name")).append("category", new Document().append("$first", "$menuItem.category"))).append("completedOrders", new Document().append("$sum", 1)).append("quantitySold", new Document().append("$sum", "$quantity")).append("revenue", new Document().append("$sum", "$totalAmount"))),
            stage("$match", new Document().append("quantitySold", new Document().append("$gte", 3))),
            stage("$sort", new Document().append("revenue", -1)),
            stage("$project", new Document().append("_id", 0).append("itemId", "$_id.itemId").append("itemName", "$_id.itemName").append("category", "$_id.category").append("completedOrders", 1).append("quantitySold", 1).append("revenue", 1))
        );
        return mongo.aggregate(aggregation, "foodOrders", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
