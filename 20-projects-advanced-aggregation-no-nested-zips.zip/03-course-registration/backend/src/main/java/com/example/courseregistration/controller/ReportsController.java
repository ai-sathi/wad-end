package com.example.courseregistration.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("capacity").is(0)),Document.class,"courses");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("courses","courseId","courseId","relatedDetails"));return mongo.aggregate(a,"registrations",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "courses").append("localField", "courseId").append("foreignField", "courseId").append("as", "course")),
            stage("$unwind", "$course"),
            stage("$match", new Document().append("status", "APPROVED")),
            stage("$group", new Document().append("_id", new Document().append("courseId", "$courseId").append("courseName", new Document().append("$first", "$course.courseName")).append("instructor", new Document().append("$first", "$course.instructor"))).append("approvedRegistrations", new Document().append("$sum", 1))),
            stage("$match", new Document().append("approvedRegistrations", new Document().append("$gt", 2))),
            stage("$sort", new Document().append("approvedRegistrations", -1)),
            stage("$project", new Document().append("_id", 0).append("courseId", "$_id.courseId").append("courseName", "$_id.courseName").append("instructor", "$_id.instructor").append("approvedRegistrations", 1))
        );
        return mongo.aggregate(aggregation, "registrations", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
