package com.example.courseregistration.controller;
import com.example.courseregistration.model.Course; import com.example.courseregistration.repository.CourseRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/courses") @CrossOrigin(origins="http://localhost:5173")
public class CourseController {
private final CourseRepository repo; public CourseController(CourseRepository repo){this.repo=repo;}
@GetMapping public List<Course> all(){return repo.findAll();}
@GetMapping("/{id}") public Course one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Course create(@RequestBody Course x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Course update(@PathVariable String id,@RequestBody Course x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
