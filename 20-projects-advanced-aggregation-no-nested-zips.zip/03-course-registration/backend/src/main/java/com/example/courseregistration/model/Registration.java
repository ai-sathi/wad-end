package com.example.courseregistration.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="registrations")
public class Registration {
@Id private String id;
private String registrationId;
private String studentName;
private String courseId;
private String semester;
private String status;
public Registration(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getRegistrationId(){return registrationId;} public void setRegistrationId(String registrationId){this.registrationId=registrationId;}
public String getStudentName(){return studentName;} public void setStudentName(String studentName){this.studentName=studentName;}
public String getCourseId(){return courseId;} public void setCourseId(String courseId){this.courseId=courseId;}
public String getSemester(){return semester;} public void setSemester(String semester){this.semester=semester;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
