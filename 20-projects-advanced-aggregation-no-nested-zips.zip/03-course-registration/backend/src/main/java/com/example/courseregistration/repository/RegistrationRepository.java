package com.example.courseregistration.repository;
import com.example.courseregistration.model.Registration;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface RegistrationRepository extends MongoRepository<Registration,String>{}
