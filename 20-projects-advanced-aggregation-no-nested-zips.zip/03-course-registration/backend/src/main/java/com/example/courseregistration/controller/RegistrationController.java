package com.example.courseregistration.controller;
import com.example.courseregistration.model.Registration; import com.example.courseregistration.repository.RegistrationRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/registrations") @CrossOrigin(origins="http://localhost:5173")
public class RegistrationController {
private final RegistrationRepository repo; public RegistrationController(RegistrationRepository repo){this.repo=repo;}
@GetMapping public List<Registration> all(){return repo.findAll();}
@GetMapping("/{id}") public Registration one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Registration create(@RequestBody Registration x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Registration update(@PathVariable String id,@RequestBody Registration x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
