package com.example.busreservation.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="buses")
public class Bus {
@Id private String id;
private String busId;
private String operator;
private String source;
private String destination;
private int availableSeats;
private double fare;
public Bus(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getBusId(){return busId;} public void setBusId(String busId){this.busId=busId;}
public String getOperator(){return operator;} public void setOperator(String operator){this.operator=operator;}
public String getSource(){return source;} public void setSource(String source){this.source=source;}
public String getDestination(){return destination;} public void setDestination(String destination){this.destination=destination;}
public int getAvailableSeats(){return availableSeats;} public void setAvailableSeats(int availableSeats){this.availableSeats=availableSeats;}
public double getFare(){return fare;} public void setFare(double fare){this.fare=fare;}
}
