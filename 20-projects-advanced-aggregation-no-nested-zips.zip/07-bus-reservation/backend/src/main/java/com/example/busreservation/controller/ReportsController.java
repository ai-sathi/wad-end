package com.example.busreservation.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("availableSeats").is(0)),Document.class,"buses");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("buses","busId","busId","relatedDetails"));return mongo.aggregate(a,"tickets",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "buses").append("localField", "busId").append("foreignField", "busId").append("as", "bus")),
            stage("$unwind", "$bus"),
            stage("$match", new Document().append("status", "BOOKED")),
            stage("$group", new Document().append("_id", new Document().append("busId", "$busId").append("operator", new Document().append("$first", "$bus.operator")).append("source", new Document().append("$first", "$bus.source")).append("destination", new Document().append("$first", "$bus.destination"))).append("bookings", new Document().append("$sum", 1)).append("seatsBooked", new Document().append("$sum", "$seatsBooked"))),
            stage("$match", new Document().append("seatsBooked", new Document().append("$gte", 4))),
            stage("$sort", new Document().append("seatsBooked", -1)),
            stage("$project", new Document().append("_id", 0).append("busId", "$_id.busId").append("operator", "$_id.operator").append("source", "$_id.source").append("destination", "$_id.destination").append("bookings", 1).append("seatsBooked", 1))
        );
        return mongo.aggregate(aggregation, "tickets", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
