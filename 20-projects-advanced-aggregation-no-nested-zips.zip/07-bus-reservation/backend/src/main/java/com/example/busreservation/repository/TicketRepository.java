package com.example.busreservation.repository;
import com.example.busreservation.model.Ticket;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface TicketRepository extends MongoRepository<Ticket,String>{}
