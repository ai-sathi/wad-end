package com.example.projecttasks.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("PENDING")),Document.class,"tasks");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("projects","projectId","projectId","relatedDetails"));return mongo.aggregate(a,"tasks",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "projects").append("localField", "projectId").append("foreignField", "projectId").append("as", "project")),
            stage("$unwind", "$project"),
            stage("$match", new Document().append("status", new Document().append("$in", java.util.Arrays.asList("PENDING", "IN_PROGRESS")))),
            stage("$group", new Document().append("_id", new Document().append("projectId", "$projectId").append("projectName", new Document().append("$first", "$project.name")).append("manager", new Document().append("$first", "$project.manager"))).append("activeTasks", new Document().append("$sum", 1))),
            stage("$match", new Document().append("activeTasks", new Document().append("$gte", 2))),
            stage("$sort", new Document().append("activeTasks", -1)),
            stage("$project", new Document().append("_id", 0).append("projectId", "$_id.projectId").append("projectName", "$_id.projectName").append("manager", "$_id.manager").append("activeTasks", 1))
        );
        return mongo.aggregate(aggregation, "tasks", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
