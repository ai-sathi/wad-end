package com.example.projecttasks.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="tasks")
public class Task {
@Id private String id;
private String taskId;
private String projectId;
private String title;
private String assignee;
private String dueDate;
private String status;
public Task(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getTaskId(){return taskId;} public void setTaskId(String taskId){this.taskId=taskId;}
public String getProjectId(){return projectId;} public void setProjectId(String projectId){this.projectId=projectId;}
public String getTitle(){return title;} public void setTitle(String title){this.title=title;}
public String getAssignee(){return assignee;} public void setAssignee(String assignee){this.assignee=assignee;}
public String getDueDate(){return dueDate;} public void setDueDate(String dueDate){this.dueDate=dueDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
