package com.example.projecttasks.controller;
import com.example.projecttasks.model.Project; import com.example.projecttasks.repository.ProjectRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/projects") @CrossOrigin(origins="http://localhost:5173")
public class ProjectController {
private final ProjectRepository repo; public ProjectController(ProjectRepository repo){this.repo=repo;}
@GetMapping public List<Project> all(){return repo.findAll();}
@GetMapping("/{id}") public Project one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Project create(@RequestBody Project x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Project update(@PathVariable String id,@RequestBody Project x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
