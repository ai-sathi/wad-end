package com.example.eventregistration.controller;
import com.example.eventregistration.model.EventRegistration; import com.example.eventregistration.repository.EventRegistrationRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/registrations") @CrossOrigin(origins="http://localhost:5173")
public class EventRegistrationController {
private final EventRegistrationRepository repo; public EventRegistrationController(EventRegistrationRepository repo){this.repo=repo;}
@GetMapping public List<EventRegistration> all(){return repo.findAll();}
@GetMapping("/{id}") public EventRegistration one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public EventRegistration create(@RequestBody EventRegistration x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public EventRegistration update(@PathVariable String id,@RequestBody EventRegistration x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
