package com.example.eventregistration.controller;
import com.example.eventregistration.model.Event; import com.example.eventregistration.repository.EventRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/events") @CrossOrigin(origins="http://localhost:5173")
public class EventController {
private final EventRepository repo; public EventController(EventRepository repo){this.repo=repo;}
@GetMapping public List<Event> all(){return repo.findAll();}
@GetMapping("/{id}") public Event one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Event create(@RequestBody Event x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Event update(@PathVariable String id,@RequestBody Event x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
