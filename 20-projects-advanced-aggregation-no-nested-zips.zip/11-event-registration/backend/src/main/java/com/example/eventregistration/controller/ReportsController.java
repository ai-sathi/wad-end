package com.example.eventregistration.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("CONFIRMED")),Document.class,"registrations");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("events","eventId","eventId","relatedDetails"));return mongo.aggregate(a,"registrations",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "events").append("localField", "eventId").append("foreignField", "eventId").append("as", "event")),
            stage("$unwind", "$event"),
            stage("$match", new Document().append("status", "CONFIRMED")),
            stage("$group", new Document().append("_id", new Document().append("eventId", "$eventId").append("eventName", new Document().append("$first", "$event.name")).append("venue", new Document().append("$first", "$event.venue"))).append("confirmedParticipants", new Document().append("$sum", 1))),
            stage("$match", new Document().append("confirmedParticipants", new Document().append("$gte", 2))),
            stage("$sort", new Document().append("confirmedParticipants", -1)),
            stage("$project", new Document().append("_id", 0).append("eventId", "$_id.eventId").append("eventName", "$_id.eventName").append("venue", "$_id.venue").append("confirmedParticipants", 1))
        );
        return mongo.aggregate(aggregation, "registrations", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
