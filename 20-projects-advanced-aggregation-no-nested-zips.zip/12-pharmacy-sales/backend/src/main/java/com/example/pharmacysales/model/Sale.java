package com.example.pharmacysales.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="sales")
public class Sale {
@Id private String id;
private String saleId;
private String customerName;
private String medicineId;
private int quantity;
private double totalAmount;
private String saleDate;
public Sale(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getSaleId(){return saleId;} public void setSaleId(String saleId){this.saleId=saleId;}
public String getCustomerName(){return customerName;} public void setCustomerName(String customerName){this.customerName=customerName;}
public String getMedicineId(){return medicineId;} public void setMedicineId(String medicineId){this.medicineId=medicineId;}
public int getQuantity(){return quantity;} public void setQuantity(int quantity){this.quantity=quantity;}
public double getTotalAmount(){return totalAmount;} public void setTotalAmount(double totalAmount){this.totalAmount=totalAmount;}
public String getSaleDate(){return saleDate;} public void setSaleDate(String saleDate){this.saleDate=saleDate;}
}
