package com.example.pharmacysales.repository;
import com.example.pharmacysales.model.Sale;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface SaleRepository extends MongoRepository<Sale,String>{}
