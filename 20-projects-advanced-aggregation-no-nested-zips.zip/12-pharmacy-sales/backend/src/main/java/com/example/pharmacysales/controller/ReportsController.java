package com.example.pharmacysales.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("stock").lt(10)),Document.class,"medicines");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("medicines","medicineId","medicineId","relatedDetails"));return mongo.aggregate(a,"sales",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "medicines").append("localField", "medicineId").append("foreignField", "medicineId").append("as", "medicine")),
            stage("$unwind", "$medicine"),
            stage("$group", new Document().append("_id", new Document().append("medicineId", "$medicineId").append("medicineName", new Document().append("$first", "$medicine.name")).append("category", new Document().append("$first", "$medicine.category"))).append("salesCount", new Document().append("$sum", 1)).append("unitsSold", new Document().append("$sum", "$quantity")).append("totalRevenue", new Document().append("$sum", "$totalAmount"))),
            stage("$match", new Document().append("totalRevenue", new Document().append("$gt", 500))),
            stage("$sort", new Document().append("totalRevenue", -1)),
            stage("$project", new Document().append("_id", 0).append("medicineId", "$_id.medicineId").append("medicineName", "$_id.medicineName").append("category", "$_id.category").append("salesCount", 1).append("unitsSold", 1).append("totalRevenue", 1))
        );
        return mongo.aggregate(aggregation, "sales", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
