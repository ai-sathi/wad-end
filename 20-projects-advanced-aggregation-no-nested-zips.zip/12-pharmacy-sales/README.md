# Pharmacy Medicine and Sales — Lab Exam Practice

Java 17 target · Spring Boot 3.3.5 · MongoDB · Vue 3 · Axios

## Included logic
- CRUD for `medicines` and `sales` (create, list, find by ID, update, delete)
- Form-based Vue UI with field inputs, records table, edit and delete actions
- Scenario-specific report: **Low-stock medicines** (`stock less than 10`)
- MongoDB aggregation join using `$lookup`: `sales.medicineId` matched to `medicines.medicineId`

## Run
1. Start MongoDB locally (`mongodb://localhost:27017`).
2. In `backend`, run `mvn spring-boot:run`.
3. In a second terminal, enter `frontend`, run `npm install` and `npm run dev`.
4. Open the Vite URL, normally `http://localhost:5173`.

## API
- GET/POST `/api/medicines`
- GET/PUT/DELETE `/api/medicines/{id}`
- GET/POST `/api/sales`
- GET/PUT/DELETE `/api/sales/{id}`
- GET `/api/reports/special`
- GET `/api/reports/joined`

The relationship field `medicineId` must have the same value in both collections for the join to match. This is a lab practice project; adjust rules to the exact question statement.
