package com.example.vehicleservice.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="vehicles")
public class Vehicle {
@Id private String id;
private String vehicleId;
private String ownerName;
private String registrationNumber;
private String model;
private int odometer;
public Vehicle(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getVehicleId(){return vehicleId;} public void setVehicleId(String vehicleId){this.vehicleId=vehicleId;}
public String getOwnerName(){return ownerName;} public void setOwnerName(String ownerName){this.ownerName=ownerName;}
public String getRegistrationNumber(){return registrationNumber;} public void setRegistrationNumber(String registrationNumber){this.registrationNumber=registrationNumber;}
public String getModel(){return model;} public void setModel(String model){this.model=model;}
public int getOdometer(){return odometer;} public void setOdometer(int odometer){this.odometer=odometer;}
}
