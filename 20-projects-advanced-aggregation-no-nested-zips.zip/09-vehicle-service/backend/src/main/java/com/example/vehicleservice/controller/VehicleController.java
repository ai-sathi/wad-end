package com.example.vehicleservice.controller;
import com.example.vehicleservice.model.Vehicle; import com.example.vehicleservice.repository.VehicleRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/vehicles") @CrossOrigin(origins="http://localhost:5173")
public class VehicleController {
private final VehicleRepository repo; public VehicleController(VehicleRepository repo){this.repo=repo;}
@GetMapping public List<Vehicle> all(){return repo.findAll();}
@GetMapping("/{id}") public Vehicle one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Vehicle create(@RequestBody Vehicle x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Vehicle update(@PathVariable String id,@RequestBody Vehicle x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
