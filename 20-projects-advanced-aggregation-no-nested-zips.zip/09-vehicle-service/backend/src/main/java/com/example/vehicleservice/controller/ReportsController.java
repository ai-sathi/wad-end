package com.example.vehicleservice.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("PENDING")),Document.class,"serviceRecords");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("vehicles","vehicleId","vehicleId","relatedDetails"));return mongo.aggregate(a,"serviceRecords",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "vehicles").append("localField", "vehicleId").append("foreignField", "vehicleId").append("as", "vehicle")),
            stage("$unwind", "$vehicle"),
            stage("$match", new Document().append("status", "COMPLETED")),
            stage("$group", new Document().append("_id", new Document().append("vehicleId", "$vehicleId").append("ownerName", new Document().append("$first", "$vehicle.ownerName")).append("model", new Document().append("$first", "$vehicle.model"))).append("completedServices", new Document().append("$sum", 1)).append("totalServiceCost", new Document().append("$sum", "$cost")).append("averageServiceCost", new Document().append("$avg", "$cost"))),
            stage("$match", new Document().append("totalServiceCost", new Document().append("$gt", 500))),
            stage("$sort", new Document().append("totalServiceCost", -1)),
            stage("$project", new Document().append("_id", 0).append("vehicleId", "$_id.vehicleId").append("ownerName", "$_id.ownerName").append("model", "$_id.model").append("completedServices", 1).append("totalServiceCost", 1).append("averageServiceCost", 1))
        );
        return mongo.aggregate(aggregation, "serviceRecords", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
