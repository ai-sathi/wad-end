package com.example.vehicleservice.controller;
import com.example.vehicleservice.model.ServiceRecord; import com.example.vehicleservice.repository.ServiceRecordRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/serviceRecords") @CrossOrigin(origins="http://localhost:5173")
public class ServiceRecordController {
private final ServiceRecordRepository repo; public ServiceRecordController(ServiceRecordRepository repo){this.repo=repo;}
@GetMapping public List<ServiceRecord> all(){return repo.findAll();}
@GetMapping("/{id}") public ServiceRecord one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public ServiceRecord create(@RequestBody ServiceRecord x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public ServiceRecord update(@PathVariable String id,@RequestBody ServiceRecord x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
