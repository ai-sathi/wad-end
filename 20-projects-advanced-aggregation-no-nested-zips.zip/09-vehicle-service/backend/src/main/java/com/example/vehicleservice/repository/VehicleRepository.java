package com.example.vehicleservice.repository;
import com.example.vehicleservice.model.Vehicle;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface VehicleRepository extends MongoRepository<Vehicle,String>{}
