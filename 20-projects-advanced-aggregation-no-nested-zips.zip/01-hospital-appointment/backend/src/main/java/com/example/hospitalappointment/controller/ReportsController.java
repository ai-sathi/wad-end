package com.example.hospitalappointment.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("PENDING")),Document.class,"appointments");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("doctors","doctorId","doctorId","relatedDetails"));return mongo.aggregate(a,"appointments",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "doctors").append("localField", "doctorId").append("foreignField", "doctorId").append("as", "doctor")),
            stage("$unwind", "$doctor"),
            stage("$match", new Document().append("status", "COMPLETED")),
            stage("$group", new Document().append("_id", new Document().append("doctorId", "$doctorId").append("doctorName", new Document().append("$first", "$doctor.name")).append("specialty", new Document().append("$first", "$doctor.specialty"))).append("completedAppointments", new Document().append("$sum", 1))),
            stage("$match", new Document().append("completedAppointments", new Document().append("$gte", 2))),
            stage("$sort", new Document().append("completedAppointments", -1)),
            stage("$project", new Document().append("_id", 0).append("doctorId", "$_id.doctorId").append("doctorName", "$_id.doctorName").append("specialty", "$_id.specialty").append("completedAppointments", 1))
        );
        return mongo.aggregate(aggregation, "appointments", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
