package com.example.hospitalappointment.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="appointments")
public class Appointment {
@Id private String id;
private String appointmentId;
private String patientName;
private String doctorId;
private String appointmentDate;
private String status;
public Appointment(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getAppointmentId(){return appointmentId;} public void setAppointmentId(String appointmentId){this.appointmentId=appointmentId;}
public String getPatientName(){return patientName;} public void setPatientName(String patientName){this.patientName=patientName;}
public String getDoctorId(){return doctorId;} public void setDoctorId(String doctorId){this.doctorId=doctorId;}
public String getAppointmentDate(){return appointmentDate;} public void setAppointmentDate(String appointmentDate){this.appointmentDate=appointmentDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
