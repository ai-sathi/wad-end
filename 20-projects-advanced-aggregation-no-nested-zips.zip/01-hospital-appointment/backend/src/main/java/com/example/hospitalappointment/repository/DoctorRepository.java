package com.example.hospitalappointment.repository;
import com.example.hospitalappointment.model.Doctor;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DoctorRepository extends MongoRepository<Doctor,String>{}
