hospital-appointment
Extract the ZIP in this folder to get the complete project.
See AGGREGATION-LAB-GUIDE.md inside the project ZIP for its scenario-specific aggregation.
