package com.example.couriertracking.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="shipments")
public class Shipment {
@Id private String id;
private String shipmentId;
private String senderName;
private String receiverName;
private String agentId;
private String dispatchDate;
private String status;
public Shipment(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getShipmentId(){return shipmentId;} public void setShipmentId(String shipmentId){this.shipmentId=shipmentId;}
public String getSenderName(){return senderName;} public void setSenderName(String senderName){this.senderName=senderName;}
public String getReceiverName(){return receiverName;} public void setReceiverName(String receiverName){this.receiverName=receiverName;}
public String getAgentId(){return agentId;} public void setAgentId(String agentId){this.agentId=agentId;}
public String getDispatchDate(){return dispatchDate;} public void setDispatchDate(String dispatchDate){this.dispatchDate=dispatchDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
