package com.example.couriertracking.repository;
import com.example.couriertracking.model.Shipment;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ShipmentRepository extends MongoRepository<Shipment,String>{}
