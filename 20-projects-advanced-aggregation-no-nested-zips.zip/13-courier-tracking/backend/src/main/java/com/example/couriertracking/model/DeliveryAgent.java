package com.example.couriertracking.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="deliveryAgents")
public class DeliveryAgent {
@Id private String id;
private String agentId;
private String name;
private String phone;
private String area;
public DeliveryAgent(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getAgentId(){return agentId;} public void setAgentId(String agentId){this.agentId=agentId;}
public String getName(){return name;} public void setName(String name){this.name=name;}
public String getPhone(){return phone;} public void setPhone(String phone){this.phone=phone;}
public String getArea(){return area;} public void setArea(String area){this.area=area;}
}
