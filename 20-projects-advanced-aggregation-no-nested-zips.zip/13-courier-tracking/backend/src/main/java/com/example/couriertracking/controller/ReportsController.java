package com.example.couriertracking.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("IN_TRANSIT")),Document.class,"shipments");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("deliveryAgents","agentId","agentId","relatedDetails"));return mongo.aggregate(a,"shipments",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "deliveryAgents").append("localField", "agentId").append("foreignField", "agentId").append("as", "agent")),
            stage("$unwind", "$agent"),
            stage("$match", new Document().append("status", "DELIVERED")),
            stage("$group", new Document().append("_id", new Document().append("agentId", "$agentId").append("agentName", new Document().append("$first", "$agent.name")).append("area", new Document().append("$first", "$agent.area"))).append("deliveredShipments", new Document().append("$sum", 1))),
            stage("$match", new Document().append("deliveredShipments", new Document().append("$gte", 2))),
            stage("$sort", new Document().append("deliveredShipments", -1)),
            stage("$project", new Document().append("_id", 0).append("agentId", "$_id.agentId").append("agentName", "$_id.agentName").append("area", "$_id.area").append("deliveredShipments", 1))
        );
        return mongo.aggregate(aggregation, "shipments", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
