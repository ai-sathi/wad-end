package com.example.couriertracking.controller;
import com.example.couriertracking.model.DeliveryAgent; import com.example.couriertracking.repository.DeliveryAgentRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/deliveryAgents") @CrossOrigin(origins="http://localhost:5173")
public class DeliveryAgentController {
private final DeliveryAgentRepository repo; public DeliveryAgentController(DeliveryAgentRepository repo){this.repo=repo;}
@GetMapping public List<DeliveryAgent> all(){return repo.findAll();}
@GetMapping("/{id}") public DeliveryAgent one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public DeliveryAgent create(@RequestBody DeliveryAgent x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public DeliveryAgent update(@PathVariable String id,@RequestBody DeliveryAgent x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
