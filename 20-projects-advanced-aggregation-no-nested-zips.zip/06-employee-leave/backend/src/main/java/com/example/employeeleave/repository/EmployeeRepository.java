package com.example.employeeleave.repository;
import com.example.employeeleave.model.Employee;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface EmployeeRepository extends MongoRepository<Employee,String>{}
