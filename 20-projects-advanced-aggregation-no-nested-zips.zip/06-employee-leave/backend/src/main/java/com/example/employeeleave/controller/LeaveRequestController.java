package com.example.employeeleave.controller;
import com.example.employeeleave.model.LeaveRequest; import com.example.employeeleave.repository.LeaveRequestRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/leaves") @CrossOrigin(origins="http://localhost:5173")
public class LeaveRequestController {
private final LeaveRequestRepository repo; public LeaveRequestController(LeaveRequestRepository repo){this.repo=repo;}
@GetMapping public List<LeaveRequest> all(){return repo.findAll();}
@GetMapping("/{id}") public LeaveRequest one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public LeaveRequest create(@RequestBody LeaveRequest x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public LeaveRequest update(@PathVariable String id,@RequestBody LeaveRequest x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
