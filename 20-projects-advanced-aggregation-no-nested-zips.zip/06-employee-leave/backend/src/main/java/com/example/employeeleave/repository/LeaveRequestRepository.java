package com.example.employeeleave.repository;
import com.example.employeeleave.model.LeaveRequest;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface LeaveRequestRepository extends MongoRepository<LeaveRequest,String>{}
