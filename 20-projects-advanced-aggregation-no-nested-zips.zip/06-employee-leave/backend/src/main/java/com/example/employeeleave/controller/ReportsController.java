package com.example.employeeleave.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("PENDING")),Document.class,"leaves");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("employees","employeeId","employeeId","relatedDetails"));return mongo.aggregate(a,"leaves",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "employees").append("localField", "employeeId").append("foreignField", "employeeId").append("as", "employee")),
            stage("$unwind", "$employee"),
            stage("$match", new Document().append("status", "APPROVED")),
            stage("$group", new Document().append("_id", new Document().append("employeeId", "$employeeId").append("employeeName", new Document().append("$first", "$employee.name")).append("department", new Document().append("$first", "$employee.department"))).append("approvedLeaveRequests", new Document().append("$sum", 1))),
            stage("$match", new Document().append("approvedLeaveRequests", new Document().append("$gte", 2))),
            stage("$sort", new Document().append("approvedLeaveRequests", -1)),
            stage("$project", new Document().append("_id", 0).append("employeeId", "$_id.employeeId").append("employeeName", "$_id.employeeName").append("department", "$_id.department").append("approvedLeaveRequests", 1))
        );
        return mongo.aggregate(aggregation, "leaves", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
