package com.example.hotelreservation.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("available").is(false)),Document.class,"rooms");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("rooms","roomId","roomId","relatedDetails"));return mongo.aggregate(a,"reservations",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "rooms").append("localField", "roomId").append("foreignField", "roomId").append("as", "room")),
            stage("$unwind", "$room"),
            stage("$match", new Document().append("status", "CONFIRMED")),
            stage("$group", new Document().append("_id", new Document().append("roomId", "$roomId").append("roomType", new Document().append("$first", "$room.roomType")).append("pricePerNight", new Document().append("$first", "$room.pricePerNight"))).append("confirmedReservations", new Document().append("$sum", 1))),
            stage("$match", new Document().append("confirmedReservations", new Document().append("$gte", 2))),
            stage("$sort", new Document().append("confirmedReservations", -1)),
            stage("$project", new Document().append("_id", 0).append("roomId", "$_id.roomId").append("roomType", "$_id.roomType").append("pricePerNight", "$_id.pricePerNight").append("confirmedReservations", 1))
        );
        return mongo.aggregate(aggregation, "reservations", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
