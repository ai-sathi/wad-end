package com.example.hotelreservation.controller;
import com.example.hotelreservation.model.Reservation; import com.example.hotelreservation.repository.ReservationRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/reservations") @CrossOrigin(origins="http://localhost:5173")
public class ReservationController {
private final ReservationRepository repo; public ReservationController(ReservationRepository repo){this.repo=repo;}
@GetMapping public List<Reservation> all(){return repo.findAll();}
@GetMapping("/{id}") public Reservation one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Reservation create(@RequestBody Reservation x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Reservation update(@PathVariable String id,@RequestBody Reservation x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
