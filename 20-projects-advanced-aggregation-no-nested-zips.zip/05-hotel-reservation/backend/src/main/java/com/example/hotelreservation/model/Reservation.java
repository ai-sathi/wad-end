package com.example.hotelreservation.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="reservations")
public class Reservation {
@Id private String id;
private String reservationId;
private String guestName;
private String roomId;
private String checkIn;
private String checkOut;
private String status;
public Reservation(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getReservationId(){return reservationId;} public void setReservationId(String reservationId){this.reservationId=reservationId;}
public String getGuestName(){return guestName;} public void setGuestName(String guestName){this.guestName=guestName;}
public String getRoomId(){return roomId;} public void setRoomId(String roomId){this.roomId=roomId;}
public String getCheckIn(){return checkIn;} public void setCheckIn(String checkIn){this.checkIn=checkIn;}
public String getCheckOut(){return checkOut;} public void setCheckOut(String checkOut){this.checkOut=checkOut;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
