package com.example.hotelreservation.controller;
import com.example.hotelreservation.model.Room; import com.example.hotelreservation.repository.RoomRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/rooms") @CrossOrigin(origins="http://localhost:5173")
public class RoomController {
private final RoomRepository repo; public RoomController(RoomRepository repo){this.repo=repo;}
@GetMapping public List<Room> all(){return repo.findAll();}
@GetMapping("/{id}") public Room one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Room create(@RequestBody Room x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Room update(@PathVariable String id,@RequestBody Room x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
