# Hotel Reservation — Advanced Aggregation Lab Guide

## Scenario question
Find rooms with at least 2 confirmed reservations; show room type and price, ordered by reservation count.

## Endpoint
`GET http://localhost:8080/api/reports/advanced`

## Aggregation stages
1. `$lookup`: joins `reservations` with `rooms` using `roomId` = `roomId`.
2. `$unwind`: turns the joined array into a single joined document.
3. `$match`: filters source records using this project's business rule.
4. `$group`: groups by the scenario entity and calculates counts/totals/averages as appropriate.
5. `$match`: filters the grouped results using a threshold.
6. `$sort`: ranks the result.
7. `$project`: returns only fields required by the question.

## Existing functionality
The original model classes, repositories, CRUD controllers, frontend, dependencies, and existing `/api/reports/special` and `/api/reports/joined` endpoints are retained. The new endpoint is additive.

## Run
1. Start MongoDB.
2. Open the `backend` folder in IntelliJ as a Maven project.
3. Run the Spring Boot main class.
4. Run the frontend with `npm install` then `npm run dev` in the frontend folder.
5. Open the endpoint above in a browser/Postman after adding data whose status values match the scenario.

**Important:** Status values are case-sensitive. The aggregation uses the exact values shown in the controller. Ensure sample records use those values.
