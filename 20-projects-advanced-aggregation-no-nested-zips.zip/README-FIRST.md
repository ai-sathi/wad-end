# Updated Full-Stack Lab Pack — 20 Projects

Each numbered folder contains one separate project ZIP. Extract a project's ZIP to work on it independently. Every project retains its Vue frontend, Spring Boot backend, MongoDB CRUD functionality, and existing reports; a scenario-specific advanced aggregation endpoint was added to its ReportsController.

The aggregation endpoint is `GET /api/reports/advanced`. Read the project's `AGGREGATION-LAB-GUIDE.md` inside its ZIP for the question and pipeline stages. Status values are case-sensitive and should match the provided scenario.
