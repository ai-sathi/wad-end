package com.example.onlineexam.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("FAIL")),Document.class,"results");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("exams","examId","examId","relatedDetails"));return mongo.aggregate(a,"results",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "exams").append("localField", "examId").append("foreignField", "examId").append("as", "exam")),
            stage("$unwind", "$exam"),
            stage("$match", new Document().append("status", "PASS")),
            stage("$group", new Document().append("_id", new Document().append("examId", "$examId").append("subject", new Document().append("$first", "$exam.subject"))).append("passedStudents", new Document().append("$sum", 1)).append("averageMarks", new Document().append("$avg", "$marksObtained")).append("highestMarks", new Document().append("$max", "$marksObtained"))),
            stage("$match", new Document().append("passedStudents", new Document().append("$gte", 2))),
            stage("$sort", new Document().append("averageMarks", -1)),
            stage("$project", new Document().append("_id", 0).append("examId", "$_id.examId").append("subject", "$_id.subject").append("passedStudents", 1).append("averageMarks", 1).append("highestMarks", 1))
        );
        return mongo.aggregate(aggregation, "results", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
