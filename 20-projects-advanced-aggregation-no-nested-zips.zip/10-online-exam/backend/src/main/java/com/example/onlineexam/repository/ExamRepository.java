package com.example.onlineexam.repository;
import com.example.onlineexam.model.Exam;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ExamRepository extends MongoRepository<Exam,String>{}
