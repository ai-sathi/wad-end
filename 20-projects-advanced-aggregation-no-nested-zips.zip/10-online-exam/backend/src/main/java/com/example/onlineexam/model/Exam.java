package com.example.onlineexam.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="exams")
public class Exam {
@Id private String id;
private String examId;
private String subject;
private String examDate;
private int totalMarks;
private int durationMinutes;
public Exam(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getExamId(){return examId;} public void setExamId(String examId){this.examId=examId;}
public String getSubject(){return subject;} public void setSubject(String subject){this.subject=subject;}
public String getExamDate(){return examDate;} public void setExamDate(String examDate){this.examDate=examDate;}
public int getTotalMarks(){return totalMarks;} public void setTotalMarks(int totalMarks){this.totalMarks=totalMarks;}
public int getDurationMinutes(){return durationMinutes;} public void setDurationMinutes(int durationMinutes){this.durationMinutes=durationMinutes;}
}
