package com.example.onlineexam.controller;
import com.example.onlineexam.model.Exam; import com.example.onlineexam.repository.ExamRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/exams") @CrossOrigin(origins="http://localhost:5173")
public class ExamController {
private final ExamRepository repo; public ExamController(ExamRepository repo){this.repo=repo;}
@GetMapping public List<Exam> all(){return repo.findAll();}
@GetMapping("/{id}") public Exam one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Exam create(@RequestBody Exam x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Exam update(@PathVariable String id,@RequestBody Exam x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
