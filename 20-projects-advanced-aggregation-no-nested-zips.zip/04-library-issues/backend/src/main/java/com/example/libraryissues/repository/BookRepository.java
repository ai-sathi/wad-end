package com.example.libraryissues.repository;
import com.example.libraryissues.model.Book;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface BookRepository extends MongoRepository<Book,String>{}
