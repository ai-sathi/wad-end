package com.example.libraryissues.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("OVERDUE")),Document.class,"issues");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("books","bookId","bookId","relatedDetails"));return mongo.aggregate(a,"issues",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "books").append("localField", "bookId").append("foreignField", "bookId").append("as", "book")),
            stage("$unwind", "$book"),
            stage("$match", new Document().append("status", "ISSUED")),
            stage("$group", new Document().append("_id", new Document().append("bookId", "$bookId").append("title", new Document().append("$first", "$book.title")).append("author", new Document().append("$first", "$book.author"))).append("activeIssues", new Document().append("$sum", 1))),
            stage("$match", new Document().append("activeIssues", new Document().append("$gte", 2))),
            stage("$sort", new Document().append("activeIssues", -1)),
            stage("$project", new Document().append("_id", 0).append("bookId", "$_id.bookId").append("title", "$_id.title").append("author", "$_id.author").append("activeIssues", 1))
        );
        return mongo.aggregate(aggregation, "issues", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
