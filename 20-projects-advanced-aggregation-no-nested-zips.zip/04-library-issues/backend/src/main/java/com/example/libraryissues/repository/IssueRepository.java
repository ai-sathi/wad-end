package com.example.libraryissues.repository;
import com.example.libraryissues.model.Issue;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface IssueRepository extends MongoRepository<Issue,String>{}
