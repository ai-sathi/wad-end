# Insurance Policy and Claims — Lab Exam Practice

Java 17 target · Spring Boot 3.3.5 · MongoDB · Vue 3 · Axios

## Included logic
- CRUD for `policies` and `claims` (create, list, find by ID, update, delete)
- Form-based Vue UI with field inputs, records table, edit and delete actions
- Scenario-specific report: **Pending claims** (`status equals PENDING`)
- MongoDB aggregation join using `$lookup`: `claims.policyId` matched to `policies.policyId`

## Run
1. Start MongoDB locally (`mongodb://localhost:27017`).
2. In `backend`, run `mvn spring-boot:run`.
3. In a second terminal, enter `frontend`, run `npm install` and `npm run dev`.
4. Open the Vite URL, normally `http://localhost:5173`.

## API
- GET/POST `/api/policies`
- GET/PUT/DELETE `/api/policies/{id}`
- GET/POST `/api/claims`
- GET/PUT/DELETE `/api/claims/{id}`
- GET `/api/reports/special`
- GET `/api/reports/joined`

The relationship field `policyId` must have the same value in both collections for the join to match. This is a lab practice project; adjust rules to the exact question statement.
