package com.example.insuranceclaims.controller;
import com.example.insuranceclaims.model.Policy; import com.example.insuranceclaims.repository.PolicyRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/policies") @CrossOrigin(origins="http://localhost:5173")
public class PolicyController {
private final PolicyRepository repo; public PolicyController(PolicyRepository repo){this.repo=repo;}
@GetMapping public List<Policy> all(){return repo.findAll();}
@GetMapping("/{id}") public Policy one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Policy create(@RequestBody Policy x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Policy update(@PathVariable String id,@RequestBody Policy x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
