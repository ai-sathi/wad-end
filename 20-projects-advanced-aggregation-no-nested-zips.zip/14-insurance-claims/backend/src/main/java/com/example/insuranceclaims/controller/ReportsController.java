package com.example.insuranceclaims.controller;

import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
    private final MongoTemplate mongo;
    public ReportsController(MongoTemplate mongo) { this.mongo = mongo; }

    // Existing report endpoints are preserved.
    @GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("PENDING")),Document.class,"claims");}
    @GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("policies","policyId","policyId","relatedDetails"));return mongo.aggregate(a,"claims",Document.class).getMappedResults();}

    // Scenario-specific advanced aggregation: $lookup + $unwind + $match + $group + post-group $match + $sort + $project.
    @GetMapping("/advanced")
    public List<Document> advanced() {
        Aggregation aggregation = newAggregation(
            stage("$lookup", new Document().append("from", "policies").append("localField", "policyId").append("foreignField", "policyId").append("as", "policy")),
            stage("$unwind", "$policy"),
            stage("$match", new Document().append("status", "APPROVED")),
            stage("$group", new Document().append("_id", new Document().append("policyId", "$policyId").append("holderName", new Document().append("$first", "$policy.holderName")).append("policyType", new Document().append("$first", "$policy.policyType"))).append("approvedClaims", new Document().append("$sum", 1)).append("approvedAmount", new Document().append("$sum", "$claimAmount")).append("largestClaim", new Document().append("$max", "$claimAmount"))),
            stage("$match", new Document().append("approvedAmount", new Document().append("$gt", 1000))),
            stage("$sort", new Document().append("approvedAmount", -1)),
            stage("$project", new Document().append("_id", 0).append("policyId", "$_id.policyId").append("holderName", "$_id.holderName").append("policyType", "$_id.policyType").append("approvedClaims", 1).append("approvedAmount", 1).append("largestClaim", 1))
        );
        return mongo.aggregate(aggregation, "claims", Document.class).getMappedResults();
    }

    private AggregationOperation stage(String operator, Object value) {
        return context -> new Document(operator, value);
    }
}
